# 方块世界 · 重做版（Android）

这是一个独立的手机 3D 方块沙盒原型，非 Mojang/Minecraft 官方产品。

## 本版实际改动
- 世界从固定 16×16 小地图扩大为 40×40 地表、20 层高度。
- 使用程序化地形起伏、沙地边缘、随机树干与树冠生成。
- 改为第一人称摄像机；右侧拖动控制视角。
- 左侧虚拟摇杆使用连续输入，并按当前摄像机 yaw 计算前后左右移动。
- 跳跃加入简单的重力/抛物线。
- 准星方向进行短距离方块射线检测，支持挖掘与放置。
- 方块可见面裁剪、地表颜色扰动和昼夜循环。
- 本地保存世界、位置、朝向、背包和生存状态。

## 当前仍然是早期原型
不是完整商业级 Minecraft 复刻：目前没有官方材质、复杂角色骨骼、真正无限区块流式加载、完整碰撞/游泳/潜行、完整合成配方或联网联机。动物与敌对生物仍是简化几何体。请不要把它误认为官方 Minecraft。

## 在 GitHub 手机端编译 APK
1. 在仓库首页删除旧的 `方块世界...zip`。
2. 上传本压缩包（文件名可保持原样），提交 Commit。
3. 仓库里的 `.github/workflows/build-apk.yml` 需要使用本项目内提供的同版 workflow（它会从仓库根目录 ZIP 解压 `BlockWorldAndroid` 后编译）。
4. 打开 Actions，等绿色成功。进入本次 run，点 Artifacts 的 `BlockWorld-debug-apk` 下载，解压得到 `app-debug.apk`。

## 技术
Android Java + OpenGL ES 2.0；Gradle 8.7；Android Gradle Plugin 8.6.1；compileSdk 35；minSdk 23。
