package com.example.blockworld;

import android.content.Context;
import android.content.SharedPreferences;
import android.opengl.GLSurfaceView;
import android.opengl.GLES20;
import android.opengl.Matrix;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.InputStream;
import android.widget.TextView;
import android.widget.Toast;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Random;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class VoxelView extends GLSurfaceView {
    private final WorldRenderer renderer;
    public VoxelView(Context c) {
        super(c); setEGLContextClientVersion(2);
        renderer = new WorldRenderer(c); setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }
    public void setStatusView(TextView v){ renderer.status=v; }
    public void move(float x,float z){ renderer.move(x,z); }
    public void turn(int d){ renderer.turn(d); }
    public void rotateCamera(float dx,float dy){ renderer.rotateCamera(dx,dy); }
    public void jump(){ renderer.jump(); }
    public void breakBlock(){ renderer.breakBlock(); }
    public void placeBlock(){ renderer.placeBlock(); }
    public void nextBlock(){ renderer.nextBlock(); }
    public void selectBlock(int slot){ renderer.selectBlock(slot); }
    public void showInventory(){ toast(renderer.inventoryText()); }
    public void craft(){ toast(renderer.craft()); }
    public void toggleMode(){ toast(renderer.toggleMode()); }
    public void eat(){ toast(renderer.eat()); }
    public void saveGame(){ renderer.save(); toast("世界已保存"); }
    public void newWorld(){ renderer.resetWorld(); toast("新世界已生成"); }
    private void toast(String s){ post(() -> Toast.makeText(getContext(),s,Toast.LENGTH_SHORT).show()); }
    @Override public void onPause(){ super.onPause(); }
    @Override public void onResume(){ super.onResume(); }

    static class WorldRenderer implements Renderer {
        private final Context context;
        private final SharedPreferences prefs;
        private int program, mvpHandle, posHandle, colorHandle, uvHandle, tintHandle, texHandle, offsetHandle, atlasTexture;
        private FloatBuffer cube;
        private final float[] projection=new float[16], view=new float[16], vp=new float[16], model=new float[16], mvp=new float[16];
        private static final int WX=40, WY=20, WZ=40;
        private final int[][][] blocks = new int[WX][WY][WZ];
        private final int[] inventory = new int[6];
        private float px=20.0f,pz=30.0f,moveX=0,moveZ=0; private int selected=1;
        private float yawOffset=0f, pitch=0f, jumpY=0f, jumpV=0f;
        private int health=20,hunger=20,planks=0,pickaxe=0;
        private boolean creative=false;
        private long worldStart=System.currentTimeMillis(),lastHunger=worldStart,lastMob=worldStart;
        private int mobX=3,mobZ=3,animalX=12,animalZ=10;
        private boolean mobAlive=true;
        volatile TextView status;
        private long lastStatus=0;
        private final float[][] colors={{0,0,0},{0.28f,0.68f,0.25f},{0.48f,0.29f,0.15f},{0.48f,0.51f,0.55f},{0.48f,0.29f,0.12f},{0.18f,0.52f,0.19f},{0.72f,0.62f,0.38f}};
        private static final String VS =
            "uniform mat4 uMVP; attribute vec3 aPos; attribute vec3 aColor; attribute vec2 aUV; varying vec3 vColor; varying vec2 vUV; uniform vec3 uTint;"+
            "void main(){vColor=aColor*uTint;vUV=aUV;gl_Position=uMVP*vec4(aPos,1.0);} ";
        private static final String FS =
            "precision mediump float; varying vec3 vColor; varying vec2 vUV; uniform sampler2D uTex; uniform vec2 uOffset;"+
            "void main(){vec2 uv=uOffset+vec2(vUV.x*0.24+0.005,vUV.y*0.49+0.005);vec4 tex=texture2D(uTex,uv);gl_FragColor=vec4(tex.rgb*vColor,1.0);}";

        WorldRenderer(Context c){ context=c.getApplicationContext(); prefs=context.getSharedPreferences("blockworld",Context.MODE_PRIVATE); generateWorld(); cube=makeCube(); load(); }
        private void generateWorld(){
            Random r=new Random(731942);
            for(int x=0;x<WX;x++) for(int z=0;z<WZ;z++){
                float wave=(float)(Math.sin(x*.23)*1.8+Math.cos(z*.19)*1.5+Math.sin((x+z)*.11)*1.2);
                int h=Math.max(3,Math.min(10,6+(int)Math.round(wave)));
                for(int y=0;y<h;y++) blocks[x][y][z]=(y==h-1)?1:(y>=h-3?2:3);
                if(h<=4) blocks[x][h-1][z]=6; // sandy shore patches
            }
            // Procedural trees with trunks, layered canopies and varied spacing.
            for(int x=3;x<WX-3;x++) for(int z=3;z<WZ-3;z++) if(r.nextFloat()<.018f){
                int ground=top(x,z); if(ground<4||ground>WY-6)continue;
                int trunk=3+r.nextInt(2);
                for(int y=0;y<trunk;y++) blocks[x][ground+y][z]=4;
                for(int dy=trunk-1;dy<=trunk+2;dy++) for(int dx=-2;dx<=2;dx++) for(int dz=-2;dz<=2;dz++){
                    int ax=x+dx,az=z+dz,ay=ground+dy;
                    if(ax>=0&&ax<WX&&az>=0&&az<WZ&&ay<WY&&Math.abs(dx)+Math.abs(dz)+(dy==trunk+2?2:0)<=4&&blocks[ax][ay][az]==0) blocks[ax][ay][az]=5;
                }
            }
            // A small spawn clearing.
            for(int x=17;x<24;x++)for(int z=27;z<34;z++){int h=top(x,z);for(int y=h;y<WY;y++)blocks[x][y][z]=0;}
        }
        private int top(int x,int z){if(x<0||x>=WX||z<0||z>=WZ)return 0;for(int y=WY-1;y>=0;y--)if(blocks[x][y][z]!=0)return y+1;return 0;}
        private FloatBuffer makeCube(){
            float[][] faces={
                {-0.5f,-0.5f,0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f},
                {0.5f,-0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f},
                {-0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f},
                {-0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f},
                {0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f},
                {-0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f}
            };
            float[] shade={0.82f,0.62f,1.0f,0.48f,0.72f,0.58f};
            float[] data=new float[36*8]; int k=0;
            float[][] uv={{0,0},{1,0},{1,1},{0,0},{1,1},{0,1}};
            for(int f=0;f<6;f++)for(int v=0;v<6;v++){
                for(int j=0;j<3;j++)data[k++]=faces[f][v*3+j];
                for(int j=0;j<3;j++)data[k++]=shade[f];
                data[k++]=uv[v][0]; data[k++]=uv[v][1];
            }
            FloatBuffer b=ByteBuffer.allocateDirect(data.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();
            b.put(data).position(0); return b;
        }
        @Override public void onSurfaceCreated(GL10 gl,EGLConfig config){
            GLES20.glClearColor(0.48f,0.72f,0.94f,1f); GLES20.glEnable(GLES20.GL_DEPTH_TEST);
            int vs=shader(GLES20.GL_VERTEX_SHADER,VS),fs=shader(GLES20.GL_FRAGMENT_SHADER,FS);
            program=GLES20.glCreateProgram(); GLES20.glAttachShader(program,vs); GLES20.glAttachShader(program,fs); GLES20.glLinkProgram(program);
            mvpHandle=GLES20.glGetUniformLocation(program,"uMVP"); tintHandle=GLES20.glGetUniformLocation(program,"uTint");
            posHandle=GLES20.glGetAttribLocation(program,"aPos"); colorHandle=GLES20.glGetAttribLocation(program,"aColor");
            uvHandle=GLES20.glGetAttribLocation(program,"aUV"); texHandle=GLES20.glGetUniformLocation(program,"uTex"); offsetHandle=GLES20.glGetUniformLocation(program,"uOffset");
            try(InputStream in=context.getAssets().open("voxel_atlas.png")){Bitmap bitmap=BitmapFactory.decodeStream(in);int[] ids=new int[1];GLES20.glGenTextures(1,ids,0);atlasTexture=ids[0];GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,atlasTexture);GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_NEAREST);GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_NEAREST);GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE);GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE);android.opengl.GLUtils.texImage2D(GLES20.GL_TEXTURE_2D,0,bitmap,0);bitmap.recycle();}catch(Exception e){android.util.Log.e("BlockWorld","Texture atlas load failed",e);}
        }
        private int shader(int type,String src){int s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);return s;}
        @Override public void onSurfaceChanged(GL10 gl,int w,int h){
            GLES20.glViewport(0,0,w,h); float ratio=(float)w/Math.max(1,h);
            Matrix.frustumM(projection,0,-ratio,ratio,-1,1,1,80);
        }
        private void drawCube(float x,float y,float z,float sx,float sy,float sz,float[] c){drawCube(x,y,z,sx,sy,sz,c,0);}
        private void drawCube(float x,float y,float z,float sx,float sy,float sz,float[] c,int type){
            Matrix.setIdentityM(model,0); Matrix.translateM(model,0,x,y,z); Matrix.scaleM(model,0,sx,sy,sz);
            Matrix.multiplyMM(mvp,0,vp,0,model,0); GLES20.glUniformMatrix4fv(mvpHandle,1,false,mvp,0);
            GLES20.glUniform3f(tintHandle,c[0],c[1],c[2]);
            int tile=(type==6)?5:Math.max(0,Math.min(7,type-1)); GLES20.glUniform2f(offsetHandle,(tile%4)*0.25f,(tile/4)*0.5f);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,36);
        }
        @Override public void onDrawFrame(GL10 gl){
            long now=System.currentTimeMillis();
            updatePlayer();
            float phase=((now-worldStart)%120000L)/120000f;
            boolean night=phase>0.58f&&phase<0.92f;
            float daylight=night?0.13f:0.48f;
            GLES20.glClearColor(daylight,night?0.17f:0.72f,night?0.30f:0.94f,1f);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
            if(now-lastHunger>90000){lastHunger=now;if(!creative&&hunger>0)hunger--;if(!creative&&hunger==0&&health>0)health--;}
            if(now-lastMob>4500){lastMob=now;Random r=new Random(now/4500);mobX=Math.max(0,Math.min(WX-1,mobX+r.nextInt(3)-1));mobZ=Math.max(0,Math.min(WZ-1,mobZ+r.nextInt(3)-1));animalX=Math.max(0,Math.min(WX-1,animalX+r.nextInt(3)-1));animalZ=Math.max(0,Math.min(WZ-1,animalZ+r.nextInt(3)-1));if(night&&mobAlive&&Math.abs(mobX-px)+Math.abs(mobZ-pz)<2&&!creative)health=Math.max(0,health-1);}
            float rad=(float)Math.toRadians(yawOffset);
            float eyeY=Math.max(1.5f,top(Math.round(px),Math.round(pz))+.62f+jumpY);
            float lookX=px+(float)Math.sin(rad)*(float)Math.cos(Math.toRadians(pitch));
            float lookZ=pz-(float)Math.cos(rad)*(float)Math.cos(Math.toRadians(pitch));
            float lookY=eyeY+(float)Math.sin(Math.toRadians(pitch));
            Matrix.setLookAtM(view,0,px,eyeY,pz,lookX,eyeY+lookY-eyeY,lookZ,0,1,0);
            Matrix.multiplyMM(vp,0,projection,0,view,0);
            GLES20.glUseProgram(program);
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0); GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,atlasTexture); GLES20.glUniform1i(texHandle,0);
            cube.position(0); GLES20.glVertexAttribPointer(posHandle,3,GLES20.GL_FLOAT,false,32,cube);
            cube.position(3); GLES20.glVertexAttribPointer(colorHandle,3,GLES20.GL_FLOAT,false,32,cube);
            cube.position(6); GLES20.glVertexAttribPointer(uvHandle,2,GLES20.GL_FLOAT,false,32,cube);
            GLES20.glEnableVertexAttribArray(posHandle); GLES20.glEnableVertexAttribArray(colorHandle); GLES20.glEnableVertexAttribArray(uvHandle);
            for(int x=Math.max(0,(int)px-18);x<Math.min(WX,(int)px+19);x++)for(int y=0;y<WY;y++)for(int z=Math.max(0,(int)pz-18);z<Math.min(WZ,(int)pz+19);z++){
                int type=blocks[x][y][z]; if(type==0)continue;
                if(y<WY-1 && blocks[x][y+1][z]!=0 && blocks[x][y][z]!=4) continue;
                float v=((x*17+z*31+y*13)%9)*.012f; float[] base=colors[Math.min(type,6)];
                drawCube(x,y,z,1,1,1,new float[]{Math.min(1,base[0]+v),Math.min(1,base[1]+v),Math.min(1,base[2]+v)},type);
            }
            // Simple roaming animal and hostile night creature.
            drawCube(animalX,top(animalX,animalZ)+0.35f,animalZ,0.65f,0.55f,0.9f,new float[]{0.86f,0.72f,0.55f});
            if(mobAlive) drawCube(mobX,top(mobX,mobZ)+0.45f,mobZ,0.55f,0.9f,0.55f,night?new float[]{0.15f,0.12f,0.22f}:new float[]{0.32f,0.42f,0.34f});
            updateStatus(night);
        }
        void move(float x,float z){moveX=Math.max(-1,Math.min(1,x));moveZ=Math.max(-1,Math.min(1,z));}
        private void updatePlayer(){
            if(jumpY>0||jumpV>0){jumpY+=jumpV; jumpV-=.018f; if(jumpY<=0){jumpY=0;jumpV=0;}}
            float len=(float)Math.sqrt(moveX*moveX+moveZ*moveZ); if(len<.05f)return;
            float f=moveZ/Math.max(1,len), str=moveX/Math.max(1,len);
            float a=(float)Math.toRadians(yawOffset); float dx=(float)Math.sin(a)*f+(float)Math.cos(a)*str;
            float dz=-(float)Math.cos(a)*f+(float)Math.sin(a)*str;
            float nx=Math.max(1.2f,Math.min(WX-1.2f,px+dx*.105f));
            float nz=Math.max(1.2f,Math.min(WZ-1.2f,pz+dz*.105f));
            if(top(Math.round(nx),Math.round(pz))<WY-2)px=nx;
            if(top(Math.round(px),Math.round(nz))<WY-2)pz=nz;
        }
        void turn(int d){yawOffset=(yawOffset+d*90f)%360f;}
        void rotateCamera(float dx,float dy){yawOffset=(yawOffset+dx*0.28f)%360f;pitch=Math.max(-78f,Math.min(78f,pitch+dy*0.24f));}
        void jump(){if(jumpY==0&&jumpV==0)jumpV=.22f;}
        private int[] target(){
            float a=(float)Math.toRadians(yawOffset), cp=(float)Math.cos(Math.toRadians(pitch));
            float vx=(float)Math.sin(a)*cp, vz=-(float)Math.cos(a)*cp, vy=(float)Math.sin(Math.toRadians(pitch));
            float eye=top(Math.round(px),Math.round(pz))+.62f;
            for(float d=.8f;d<=5.0f;d+=.25f){int x=Math.round(px+vx*d),z=Math.round(pz+vz*d),y=Math.round(eye+vy*d);if(x>=0&&x<WX&&z>=0&&z<WZ&&y>=0&&y<WY&&blocks[x][y][z]!=0)return new int[]{x,y,z};}
            int x=Math.max(0,Math.min(WX-1,Math.round(px+vx*3))),z=Math.max(0,Math.min(WZ-1,Math.round(pz+vz*3)));return new int[]{x,Math.max(0,top(x,z)-1),z};
        }
        void breakBlock(){int[] t=target();int type=blocks[t[0]][t[1]][t[2]];if(type!=0){blocks[t[0]][t[1]][t[2]]=0;if(!creative&&type<inventory.length)inventory[type]++;}}
        void placeBlock(){int[] t=target();float a=(float)Math.toRadians(yawOffset);int x=Math.max(0,Math.min(WX-1,t[0]-(Math.abs(Math.sin(a))>Math.abs(Math.cos(a))?(int)Math.signum(Math.sin(a)):0)));int z=Math.max(0,Math.min(WZ-1,t[2]+(Math.abs(Math.cos(a))>=Math.abs(Math.sin(a))?(int)Math.signum(Math.cos(a)):0)));int y=Math.min(WY-1,t[1]+1);if(blocks[x][y][z]==0&&(creative||inventory[selected]>0)){blocks[x][y][z]=selected;if(!creative)inventory[selected]--;}}
        void nextBlock(){selected=selected%5+1;}
        void selectBlock(int slot){selected=(Math.max(0,slot)%5)+1;}
        String inventoryText(){return "背包：草 "+inventory[1]+"、泥土 "+inventory[2]+"、石头 "+inventory[3]+"、木头 "+inventory[4]+"、树叶 "+inventory[5]+"；木板 "+planks+"；木镐 "+pickaxe;}
        String craft(){
            if(creative){planks+=4;pickaxe++;return "创造模式：已获得 4 木板和 1 木镐";}
            if(inventory[4]>=1){inventory[4]--;planks+=4;return "合成成功：1 木头 → 4 木板";}
            if(inventory[3]>=2&&planks>=2){inventory[3]-=2;planks-=2;pickaxe++;return "合成成功：2 石头 + 2 木板 → 1 石镐（工具计数）";}
            return "材料不足：木板配方需要 1 木头；石镐需要 2 石头和 2 木板";
        }
        String toggleMode(){creative=!creative;if(creative){health=20;hunger=20;}return creative?"已切换到创造模式（无限放置）":"已切换到生存模式（生命与饥饿开启）";}
        String eat(){if(creative){hunger=20;return "创造模式：状态已恢复";}if(inventory[5]>0){inventory[5]--;hunger=Math.min(20,hunger+5);return "吃了树叶？这是原型测试食物，饥饿值 +5";}if(planks>0){planks--;hunger=Math.min(20,hunger+4);return "吃掉测试口粮，饥饿值 +4";}return "没有食物。先收集树叶或合成木板来测试进食。";}
        void save(){
            StringBuilder b=new StringBuilder();for(int x=0;x<WX;x++)for(int y=0;y<WY;y++)for(int z=0;z<WZ;z++)b.append((char)('0'+blocks[x][y][z]));
            StringBuilder inv=new StringBuilder();for(int i=0;i<6;i++)inv.append(inventory[i]).append(",");
            prefs.edit().putString("world",b.toString()).putString("inventory",inv.toString())
                .putFloat("px",px).putFloat("pz",pz).putFloat("yaw",yawOffset).putInt("selected",selected)
                .putInt("health",health).putInt("hunger",hunger).putInt("planks",planks).putInt("pickaxe",pickaxe)
                .putBoolean("creative",creative).putInt("mobX",mobX).putInt("mobZ",mobZ)
                .putInt("animalX",animalX).putInt("animalZ",animalZ).apply();
        }
        private void load(){
            String w=prefs.getString("world","");if(w.length()==WX*WY*WZ){int k=0;for(int x=0;x<WX;x++)for(int y=0;y<WY;y++)for(int z=0;z<WZ;z++)blocks[x][y][z]=w.charAt(k++)-'0';}
            String[] a=prefs.getString("inventory","").split(",");for(int i=0;i<Math.min(6,a.length);i++)try{inventory[i]=Integer.parseInt(a[i]);}catch(Exception ignored){}
            px=prefs.getFloat("px",px);pz=prefs.getFloat("pz",pz);yawOffset=prefs.getFloat("yaw",yawOffset);selected=prefs.getInt("selected",selected);
            health=prefs.getInt("health",health);hunger=prefs.getInt("hunger",hunger);planks=prefs.getInt("planks",0);pickaxe=prefs.getInt("pickaxe",0);
            creative=prefs.getBoolean("creative",false);mobX=prefs.getInt("mobX",mobX);mobZ=prefs.getInt("mobZ",mobZ);
            animalX=prefs.getInt("animalX",animalX);animalZ=prefs.getInt("animalZ",animalZ);
        }
        void resetWorld(){for(int x=0;x<WX;x++)for(int y=0;y<WY;y++)for(int z=0;z<WZ;z++)blocks[x][y][z]=0;for(int i=0;i<6;i++)inventory[i]=0;px=20;pz=30;yawOffset=0;jumpY=0;jumpV=0;health=20;hunger=20;planks=0;pickaxe=0;creative=false;worldStart=System.currentTimeMillis();generateWorld();save();}
        private void updateStatus(boolean night){
            long now=System.currentTimeMillis();if(status==null||now-lastStatus<400)return;lastStatus=now;
            final String s=(creative?"创造":"生存")+" | ❤ "+health+"/20 | 饥饿 "+hunger+"/20 | "+(night?"夜晚":"白天")+
                " | 方块："+new String[]{"","草","泥土","石头","木头","树叶"}[selected]+" | 坐标 "+(int)px+","+(int)pz;
            status.post(()->status.setText(s));
        }
    }
}
