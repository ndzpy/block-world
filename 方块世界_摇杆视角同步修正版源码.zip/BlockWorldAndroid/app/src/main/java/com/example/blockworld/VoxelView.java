package com.example.blockworld;

import android.content.Context;
import android.content.SharedPreferences;
import android.opengl.GLSurfaceView;
import android.opengl.GLES20;
import android.opengl.Matrix;
import android.widget.TextView;
import android.widget.Toast;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Random;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class VoxelView extends GLSurfaceView {
    private final WorldRenderer renderer;
    public VoxelView(Context c) {
        super(c); setEGLContextClientVersion(2);
        renderer = new WorldRenderer(c); setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }
    public void setStatusView(TextView v){ renderer.status=v; }
    public void move(int x,int z){ renderer.move(x,z); }
    public void turn(int d){ renderer.turn(d); }
    public void rotateCamera(float dx,float dy){ renderer.rotateCamera(dx,dy); }
    public void jump(){ renderer.jump(); }
    public void breakBlock(){ renderer.breakBlock(); }
    public void placeBlock(){ renderer.placeBlock(); }
    public void nextBlock(){ renderer.nextBlock(); }
    public void showInventory(){ toast(renderer.inventoryText()); }
    public void craft(){ toast(renderer.craft()); }
    public void toggleMode(){ toast(renderer.toggleMode()); }
    public void eat(){ toast(renderer.eat()); }
    public void saveGame(){ renderer.save(); toast("世界已保存"); }
    public void newWorld(){ renderer.resetWorld(); toast("新世界已生成"); }
    private void toast(String s){ post(() -> Toast.makeText(getContext(),s,Toast.LENGTH_SHORT).show()); }
    @Override public void onPause(){ super.onPause(); }
    @Override public void onResume(){ super.onResume(); }

    static class WorldRenderer implements Renderer {
        private final Context context;
        private final SharedPreferences prefs;
        private int program, mvpHandle, posHandle, colorHandle, tintHandle;
        private FloatBuffer cube;
        private final float[] projection=new float[16], view=new float[16], vp=new float[16], model=new float[16], mvp=new float[16];
        private final int[][][] blocks = new int[16][8][16];
        private final int[] inventory = new int[6];
        private int px=8,pz=13,dir=0,selected=1;
        private float yawOffset=0f, pitch=0f;
        private int health=20,hunger=20,planks=0,pickaxe=0;
        private boolean creative=false;
        private long worldStart=System.currentTimeMillis(),lastHunger=worldStart,lastMob=worldStart;
        private int mobX=3,mobZ=3,animalX=12,animalZ=10;
        private boolean mobAlive=true;
        volatile TextView status;
        private long lastStatus=0;
        private final float[][] colors={{0,0,0},{0.28f,0.68f,0.25f},{0.48f,0.29f,0.15f},{0.48f,0.51f,0.55f},{0.48f,0.29f,0.12f},{0.18f,0.52f,0.19f}};
        private static final String VS =
            "uniform mat4 uMVP; attribute vec3 aPos; attribute vec3 aColor; varying vec3 vColor; uniform vec3 uTint;"+
            "void main(){vColor=aColor*uTint;gl_Position=uMVP*vec4(aPos,1.0);}";
        private static final String FS =
            "precision mediump float; varying vec3 vColor;"+
            "void main(){gl_FragColor=vec4(vColor,1.0);}";

        WorldRenderer(Context c){ context=c.getApplicationContext(); prefs=context.getSharedPreferences("blockworld",Context.MODE_PRIVATE); generateWorld(); cube=makeCube(); load(); }
        private void generateWorld(){
            for(int x=0;x<16;x++) for(int z=0;z<16;z++){
                int h=2+new Random(x*91+z*17+11).nextInt(3);
                for(int y=0;y<h;y++) blocks[x][y][z]=(y==h-1)?1:(y==0?3:2);
            }
            for(int x=2;x<15;x+=4) for(int z=2;z<15;z+=5){
                int ground=top(x,z);
                for(int y=0;y<3;y++) if(ground+y<8) blocks[x][ground+y][z]=4;
                for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++)
                    for(int dy=2;dy<=3;dy++){
                        int ax=x+dx,az=z+dz,ay=ground+dy;
                        if(ax>=0&&ax<16&&az>=0&&az<16&&ay<8&&blocks[ax][ay][az]==0) blocks[ax][ay][az]=5;
                    }
            }
        }
        private int top(int x,int z){for(int y=7;y>=0;y--)if(blocks[x][y][z]!=0)return y+1;return 0;}
        private FloatBuffer makeCube(){
            float[][] faces={
                {-0.5f,-0.5f,0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f},
                {0.5f,-0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f},
                {-0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f},
                {-0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f},
                {0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f},
                {-0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f}
            };
            float[] shade={0.82f,0.62f,1.0f,0.48f,0.72f,0.58f};
            float[] data=new float[36*6]; int k=0;
            for(int f=0;f<6;f++)for(int v=0;v<6;v++){
                for(int j=0;j<3;j++)data[k++]=faces[f][v*3+j];
                for(int j=0;j<3;j++)data[k++]=shade[f];
            }
            FloatBuffer b=ByteBuffer.allocateDirect(data.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();
            b.put(data).position(0); return b;
        }
        @Override public void onSurfaceCreated(GL10 gl,EGLConfig config){
            GLES20.glClearColor(0.48f,0.72f,0.94f,1f); GLES20.glEnable(GLES20.GL_DEPTH_TEST);
            int vs=shader(GLES20.GL_VERTEX_SHADER,VS),fs=shader(GLES20.GL_FRAGMENT_SHADER,FS);
            program=GLES20.glCreateProgram(); GLES20.glAttachShader(program,vs); GLES20.glAttachShader(program,fs); GLES20.glLinkProgram(program);
            mvpHandle=GLES20.glGetUniformLocation(program,"uMVP"); tintHandle=GLES20.glGetUniformLocation(program,"uTint");
            posHandle=GLES20.glGetAttribLocation(program,"aPos"); colorHandle=GLES20.glGetAttribLocation(program,"aColor");
        }
        private int shader(int type,String src){int s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);return s;}
        @Override public void onSurfaceChanged(GL10 gl,int w,int h){
            GLES20.glViewport(0,0,w,h); float ratio=(float)w/Math.max(1,h);
            Matrix.frustumM(projection,0,-ratio,ratio,-1,1,1,80);
        }
        private void drawCube(float x,float y,float z,float sx,float sy,float sz,float[] c){
            Matrix.setIdentityM(model,0); Matrix.translateM(model,0,x,y,z); Matrix.scaleM(model,0,sx,sy,sz);
            Matrix.multiplyMM(mvp,0,vp,0,model,0); GLES20.glUniformMatrix4fv(mvpHandle,1,false,mvp,0);
            GLES20.glUniform3f(tintHandle,c[0],c[1],c[2]); GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,36);
        }
        @Override public void onDrawFrame(GL10 gl){
            long now=System.currentTimeMillis();
            float phase=((now-worldStart)%120000L)/120000f;
            boolean night=phase>0.58f&&phase<0.92f;
            float daylight=night?0.13f:0.48f;
            GLES20.glClearColor(daylight,night?0.17f:0.72f,night?0.30f:0.94f,1f);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
            if(now-lastHunger>90000){lastHunger=now;if(!creative&&hunger>0)hunger--;if(!creative&&hunger==0&&health>0)health--;}
            if(now-lastMob>4500){lastMob=now;Random r=new Random(now/4500);mobX=Math.max(0,Math.min(15,mobX+r.nextInt(3)-1));mobZ=Math.max(0,Math.min(15,mobZ+r.nextInt(3)-1));animalX=Math.max(0,Math.min(15,animalX+r.nextInt(3)-1));animalZ=Math.max(0,Math.min(15,animalZ+r.nextInt(3)-1));if(night&&mobAlive&&Math.abs(mobX-px)+Math.abs(mobZ-pz)<2&&!creative)health=Math.max(0,health-1);}
            float rad=(float)Math.toRadians(dir*90+yawOffset);
            float lookY=1.5f+(float)Math.sin(Math.toRadians(pitch))*4f;
            float cx=px-(float)Math.sin(rad)*7, cz=pz-(float)Math.cos(rad)*7;
            Matrix.setLookAtM(view,0,cx,6.5f,cz,px,lookY,pz,0,1,0);
            Matrix.multiplyMM(vp,0,projection,0,view,0);
            GLES20.glUseProgram(program);
            cube.position(0); GLES20.glVertexAttribPointer(posHandle,3,GLES20.GL_FLOAT,false,24,cube);
            cube.position(3); GLES20.glVertexAttribPointer(colorHandle,3,GLES20.GL_FLOAT,false,24,cube);
            GLES20.glEnableVertexAttribArray(posHandle); GLES20.glEnableVertexAttribArray(colorHandle);
            for(int x=0;x<16;x++)for(int y=0;y<8;y++)for(int z=0;z<16;z++){
                int type=blocks[x][y][z]; if(type==0)continue;
                drawCube(x,y,z,1,1,1,colors[type]);
            }
            // Simple roaming animal and hostile night creature.
            drawCube(animalX,top(animalX,animalZ)+0.35f,animalZ,0.65f,0.55f,0.9f,new float[]{0.86f,0.72f,0.55f});
            if(mobAlive) drawCube(mobX,top(mobX,mobZ)+0.45f,mobZ,0.55f,0.9f,0.55f,night?new float[]{0.15f,0.12f,0.22f}:new float[]{0.32f,0.42f,0.34f});
            updateStatus(night);
        }
        // Move in camera-relative directions, like Minecraft mobile controls.
        // z=1 means forward on the joystick; x=1 means right.
        void move(int x,int z){
            float yaw=(float)Math.toRadians(dir*90f+yawOffset);
            float worldX=x*(float)Math.cos(yaw)+z*(float)Math.sin(yaw);
            float worldZ=-x*(float)Math.sin(yaw)+z*(float)Math.cos(yaw);
            int fx=Math.round(worldX), fz=Math.round(worldZ);
            // Keep diagonal movement responsive without moving faster than cardinal movement.
            if(fx==0 && fz==0) return;
            int nx=Math.max(0,Math.min(15,px+fx)), nz=Math.max(0,Math.min(15,pz+fz));
            if(top(nx,nz)<7){px=nx;pz=nz;}
        }
        void turn(int d){dir=(dir+d+4)%4;}
        void rotateCamera(float dx,float dy){yawOffset=(yawOffset+dx*0.45f)%360f;pitch=Math.max(-55f,Math.min(55f,pitch+dy*0.35f));}
        void jump(){px=Math.max(0,Math.min(15,px));}
        private int[] target(){
            float yaw=(float)Math.toRadians(dir*90f+yawOffset);
            int tx=px+Math.round((float)Math.sin(yaw));
            int tz=pz-Math.round((float)Math.cos(yaw));
            return new int[]{Math.max(0,Math.min(15,tx)),Math.max(0,Math.min(15,tz))};
        }
        void breakBlock(){int[] t=target();int y=top(t[0],t[1])-1;if(y>=0){int type=blocks[t[0]][y][t[1]];if(type!=0){blocks[t[0]][y][t[1]]=0;if(!creative&&type<inventory.length)inventory[type]++;}}}
        void placeBlock(){int[] t=target();int y=top(t[0],t[1]);if(y<8&&(creative||inventory[selected]>0)){blocks[t[0]][y][t[1]]=selected;if(!creative)inventory[selected]--;}}
        void nextBlock(){selected=selected%5+1;}
        String inventoryText(){return "背包：草 "+inventory[1]+"、泥土 "+inventory[2]+"、石头 "+inventory[3]+"、木头 "+inventory[4]+"、树叶 "+inventory[5]+"；木板 "+planks+"；木镐 "+pickaxe;}
        String craft(){
            if(creative){planks+=4;pickaxe++;return "创造模式：已获得 4 木板和 1 木镐";}
            if(inventory[4]>=1){inventory[4]--;planks+=4;return "合成成功：1 木头 → 4 木板";}
            if(inventory[3]>=2&&planks>=2){inventory[3]-=2;planks-=2;pickaxe++;return "合成成功：2 石头 + 2 木板 → 1 石镐（工具计数）";}
            return "材料不足：木板配方需要 1 木头；石镐需要 2 石头和 2 木板";
        }
        String toggleMode(){creative=!creative;if(creative){health=20;hunger=20;}return creative?"已切换到创造模式（无限放置）":"已切换到生存模式（生命与饥饿开启）";}
        String eat(){if(creative){hunger=20;return "创造模式：状态已恢复";}if(inventory[5]>0){inventory[5]--;hunger=Math.min(20,hunger+5);return "吃了树叶？这是原型测试食物，饥饿值 +5";}if(planks>0){planks--;hunger=Math.min(20,hunger+4);return "吃掉测试口粮，饥饿值 +4";}return "没有食物。先收集树叶或合成木板来测试进食。";}
        void save(){
            StringBuilder b=new StringBuilder();for(int x=0;x<16;x++)for(int y=0;y<8;y++)for(int z=0;z<16;z++)b.append(blocks[x][y][z]);
            StringBuilder inv=new StringBuilder();for(int i=0;i<6;i++)inv.append(inventory[i]).append(",");
            prefs.edit().putString("world",b.toString()).putString("inventory",inv.toString())
                .putInt("px",px).putInt("pz",pz).putInt("dir",dir).putInt("selected",selected)
                .putInt("health",health).putInt("hunger",hunger).putInt("planks",planks).putInt("pickaxe",pickaxe)
                .putBoolean("creative",creative).putInt("mobX",mobX).putInt("mobZ",mobZ)
                .putInt("animalX",animalX).putInt("animalZ",animalZ).apply();
        }
        private void load(){
            String w=prefs.getString("world","");if(w.length()==16*8*16){int k=0;for(int x=0;x<16;x++)for(int y=0;y<8;y++)for(int z=0;z<16;z++)blocks[x][y][z]=w.charAt(k++)-'0';}
            String[] a=prefs.getString("inventory","").split(",");for(int i=0;i<Math.min(6,a.length);i++)try{inventory[i]=Integer.parseInt(a[i]);}catch(Exception ignored){}
            px=prefs.getInt("px",px);pz=prefs.getInt("pz",pz);dir=prefs.getInt("dir",dir);selected=prefs.getInt("selected",selected);
            health=prefs.getInt("health",health);hunger=prefs.getInt("hunger",hunger);planks=prefs.getInt("planks",0);pickaxe=prefs.getInt("pickaxe",0);
            creative=prefs.getBoolean("creative",false);mobX=prefs.getInt("mobX",mobX);mobZ=prefs.getInt("mobZ",mobZ);
            animalX=prefs.getInt("animalX",animalX);animalZ=prefs.getInt("animalZ",animalZ);
        }
        void resetWorld(){for(int x=0;x<16;x++)for(int y=0;y<8;y++)for(int z=0;z<16;z++)blocks[x][y][z]=0;for(int i=0;i<6;i++)inventory[i]=0;px=8;pz=13;dir=0;health=20;hunger=20;planks=0;pickaxe=0;creative=false;worldStart=System.currentTimeMillis();generateWorld();save();}
        private void updateStatus(boolean night){
            long now=System.currentTimeMillis();if(status==null||now-lastStatus<400)return;lastStatus=now;
            final String s=(creative?"创造":"生存")+" | ❤ "+health+"/20 | 饥饿 "+hunger+"/20 | "+(night?"夜晚":"白天")+
                " | 方块："+new String[]{"","草","泥土","石头","木头","树叶"}[selected]+" | 坐标 "+px+","+pz;
            status.post(()->status.setText(s));
        }
    }
}
