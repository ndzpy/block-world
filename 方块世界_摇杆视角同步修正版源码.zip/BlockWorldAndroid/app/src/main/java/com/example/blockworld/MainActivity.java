package com.example.blockworld;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    private VoxelView game;
    private TextView status;
    @Override public void onCreate(Bundle b){super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        FrameLayout root=new FrameLayout(this); game=new VoxelView(this); root.addView(game);
        status=new TextView(this);status.setTextColor(Color.WHITE);status.setTextSize(13);status.setPadding(14,8,14,8);status.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);sp.topMargin=10;root.addView(status,sp);game.setStatusView(status);
        root.addView(new Controls(this));setContentView(root);
    }
    private class Controls extends View {
        Paint p=new Paint(3); float sx,sy,stickX,stickY; boolean stick=false; float lastX,lastY; long lastMove=0; int slot=0;
        Controls(Activity a){super(a);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void fill(Canvas c,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);}
        void circle(Canvas c,float x,float y,float r,int color){fill(c,color);c.drawCircle(x,y,r,p);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();
            // Crosshair
            p.setColor(0xeeeeeeee);p.setStrokeWidth(2.2f);c.drawLine(w/2-12,h/2,w/2+12,h/2,p);c.drawLine(w/2,h/2-12,w/2,h/2+12,p);
            // Virtual joystick
            sx=105;sy=h-122;circle(c,sx,sy,67,0x55333333);circle(c,sx,sy,61,0x55777777);circle(c,sx+(stick?stickX:0),sy+(stick?stickY:0),27,0x99eeeeee);
            // Hotbar
            float cell=43, total=cell*9, left=(w-total)/2, by=h-58;
            for(int i=0;i<9;i++){fill(c,i==slot?0xffeeeeee:0xaa222222);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(i==slot?3:1);c.drawRect(left+i*cell,by,left+(i+1)*cell-2,by+42,p);p.setStyle(Paint.Style.FILL);p.setColor(new int[]{0xff5b9b42,0xff8b5a32,0xff888888,0xff6b4328,0xff397a32}[i%5]);c.drawRect(left+i*cell+9,by+10,left+i*cell+31,by+32,p);}
            // Action buttons
            button(c,w-83,h-105,35,"跳",0xaa333333);button(c,w-155,h-70,29,"潜",0xaa333333);button(c,w-80,h-195,38,"挖",0xaa8b4b36);button(c,w-165,h-165,32,"放",0xaa477b3d);
            // Inventory/menu hint
            fill(c,0x77333333);c.drawRoundRect(12,h-54,95,h-16,10,10,p);p.setColor(Color.WHITE);p.setTextSize(15);c.drawText("背包",31,h-29,p);
        }
        void button(Canvas c,float x,float y,float r,String text,int color){circle(c,x,y,r,color);p.setColor(Color.WHITE);p.setTextSize(16);p.setTextAlign(Paint.Align.CENTER);c.drawText(text,x,y+6,p);p.setTextAlign(Paint.Align.LEFT);}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){int a=e.getActionMasked();float x=e.getX(),y=e.getY();
            if(a==MotionEvent.ACTION_DOWN){lastX=x;lastY=y;if(x<getWidth()*0.42f&&y>getHeight()*0.55f){stick=true;updateStick(x,y);}invalidate();return true;}
            if(a==MotionEvent.ACTION_POINTER_DOWN)return true;
            if(a==MotionEvent.ACTION_MOVE){if(stick){updateStick(x,y);long now=System.currentTimeMillis();if(now-lastMove>120){int dx=Math.abs(stickX)>12?(stickX<0?-1:1):0;int dz=Math.abs(stickY)>12?(stickY<0?1:-1):0;if(dx!=0||dz!=0)game.move(dx,dz);lastMove=now;}}else{game.rotateCamera(x-lastX,y-lastY);}lastX=x;lastY=y;invalidate();return true;}
            if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_CANCEL){if(stick){stick=false;stickX=stickY=0;}else{float w=getWidth(),h=getHeight();if(x>w-125&&y>h-155&&y<h-55)game.jump();else if(x>w-125&&y>h-245&&y<h-145)game.breakBlock();else if(x>w-205&&y>h-205&&y<h-110)game.placeBlock();else if(y>h-65&&x>(w-387)/2&&x<(w+387)/2){slot=Math.max(0,Math.min(8,(int)((x-(w-387)/2)/43)));game.nextBlock();}else if(x<110&&y>h-65)game.showInventory();}invalidate();return true;}return true;
        }
        void updateStick(float x,float y){stickX=Math.max(-38,Math.min(38,x-sx));stickY=Math.max(-38,Math.min(38,y-sy));}
    }
    @Override protected void onPause(){super.onPause();game.saveGame();game.onPause();}
    @Override protected void onResume(){super.onResume();game.onResume();}
}
