package com.example.blockworld;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private VoxelView game;
    private TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);

        FrameLayout root = new FrameLayout(this);
        game = new VoxelView(this);
        root.addView(game);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(8,8,8,8);
        panel.setBackgroundColor(0x66334455);
        TextView title = new TextView(this);
        title.setText("方块世界  |  移动 · 建造 · 生存");
        title.setTextColor(Color.WHITE); title.setTextSize(14);
        panel.addView(title);

        LinearLayout row1 = new LinearLayout(this);
        addButton(row1, "↶", v -> game.turn(-1));
        addButton(row1, "前进", v -> game.move(0,1));
        addButton(row1, "↷", v -> game.turn(1));
        panel.addView(row1);
        LinearLayout row2 = new LinearLayout(this);
        addButton(row2, "左移", v -> game.move(-1,0));
        addButton(row2, "后退", v -> game.move(0,-1));
        addButton(row2, "右移", v -> game.move(1,0));
        panel.addView(row2);
        LinearLayout row3 = new LinearLayout(this);
        addButton(row3, "挖掘", v -> game.breakBlock());
        addButton(row3, "放置", v -> game.placeBlock());
        addButton(row3, "换方块", v -> game.nextBlock());
        panel.addView(row3);
        LinearLayout row4 = new LinearLayout(this);
        addButton(row4, "背包", v -> game.showInventory());
        addButton(row4, "合成", v -> game.craft());
        addButton(row4, "生存/创造", v -> game.toggleMode());
        panel.addView(row4);
        LinearLayout row5 = new LinearLayout(this);
        addButton(row5, "吃东西", v -> game.eat());
        addButton(row5, "保存世界", v -> game.saveGame());
        addButton(row5, "重新开始", v -> game.newWorld());
        panel.addView(row5);

        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM | Gravity.LEFT);
        root.addView(panel, cp);

        status = new TextView(this);
        status.setTextColor(Color.WHITE); status.setTextSize(13);
        status.setPadding(10,8,10,8); status.setBackgroundColor(0x99556677);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP | Gravity.RIGHT);
        root.addView(status, sp);
        game.setStatusView(status);
        setContentView(root);
    }

    private void addButton(LinearLayout row, String text, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(text); button.setTextSize(11);
        button.setPadding(2,0,2,0);
        row.addView(button, new LinearLayout.LayoutParams(0, 43, 1));
        button.setOnClickListener(listener);
    }

    @Override protected void onPause(){ super.onPause(); game.saveGame(); game.onPause(); }
    @Override protected void onResume(){ super.onResume(); game.onResume(); }
}
