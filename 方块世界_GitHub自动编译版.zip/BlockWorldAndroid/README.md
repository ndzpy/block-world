# 方块世界 Android 项目（增强原型）

这是原生 Android + OpenGL ES 2.0 的可导入 Android Studio 项目，不是网页。

## 已加入的玩法原型
- 3D 方块地形、树木、可漫游动物和夜间敌对生物
- 手机按钮移动、转向、挖掘、放置、切换方块
- 背包计数与方块收集
- 简单合成：1 木头 → 4 木板；2 石头 + 2 木板 → 石镐计数
- 生存/创造模式切换
- 生存模式生命、饥饿值、随时间消耗；夜间怪物靠近会造成伤害
- 白天/夜晚天空颜色变化
- 本机世界、背包、位置和状态自动保存；也可手动保存
- 重新开始生成新世界

## 生成 APK
1. 在电脑安装 Android Studio 和 Android SDK 35。
2. 解压项目，在 Android Studio 选择 Open，打开 `BlockWorldAndroid` 文件夹。
3. 等待 Gradle 同步（首次需要联网下载 Android Gradle 插件及 SDK）。
4. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
5. APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。

## 重要说明
这是独立的方块沙盒游戏原型，非 Mojang 官方《Minecraft》，不使用其官方代码或素材。
当前地图为 16×16 小型固定区域；动物/怪物是简单方块实体；进食和合成是演示机制。
尚未达到商业级完整游戏：没有无限地图、精细角色动画、复杂寻路、真正的物品图标/装备耐久、多人联机或完整碰撞系统。
