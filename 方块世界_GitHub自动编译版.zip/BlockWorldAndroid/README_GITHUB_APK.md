# 用 GitHub Actions 自动编译 APK

1. 在 GitHub 网站登录后，点右上角 **+** → **New repository**。
2. 仓库名填写 `BlockWorldAndroid`，选择 **Public** 或 **Private**，然后创建仓库。
3. 在新仓库页面选择 **Add file** → **Upload files**。
4. 将本项目文件夹里的所有内容上传（注意是文件夹内部的内容，必须能直接看到 `settings.gradle`、`build.gradle`、`app/` 和 `.github/`）。提交上传。
5. 打开仓库的 **Actions** 页面，选择 **Build Android APK**，点 **Run workflow** → 再点绿色的 **Run workflow**。
6. 等待任务完成（首次编译可能需要几分钟）。点击成功的运行记录，在页面下方 **Artifacts** 区域下载 `BlockWorld-debug-apk`。
7. 解压下载的 ZIP，里面的 `app-debug.apk` 就是安装包。把 APK 下载到安卓手机后打开安装；如果系统提示，允许该来源安装应用。

如果 Actions 页面提示工作流未启用，请在页面中点击启用工作流。若编译失败，打开红色失败任务，把最下面的错误信息截图发来，我可以继续帮你修。

这是未签名的 debug 测试 APK，适合个人测试，不是上架 Google Play 的正式发布包。
